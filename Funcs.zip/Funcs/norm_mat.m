function [ Y ] = norm_mat( X )
%norm_mat norm of X(:)

Y = norm(X(:));

end

